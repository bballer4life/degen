run with PS console:

.\FindTheWinner.Cmd.exe ".\MyAddresses.csv"

to check how it looks like when something is found:

.\FindTheWinner.Cmd.exe ".\MyAddressesWithFakeWinners.csv"